from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.home),
    path('showall',views.todoView),
    path('add',views.additem),
    path('delete/<int:todo_id>',views.deleteitem),
    path('back',views.back),
]
