from django.shortcuts import render
from django.http import HttpResponse ,HttpResponseRedirect
from .models import TodoItem
def home(request):
    return render(request,'base.html')
def todoView(request):
    all_todo_items=TodoItem.objects.all()
    return render (request,'todo.html',{'all_items':all_todo_items})    
# Create your views here.

def additem(request):
    if request.method=='POST':
       c= request.POST['content']
       t=request.POST['time']
       new_item=TodoItem(content=c, time=t)

       new_item.save()
       return HttpResponseRedirect('showall')

def deleteitem(request,todo_id):
    print(todo_id)
    item_to_delete=TodoItem.objects.get(id=todo_id)
    item_to_delete.delete()
    return HttpResponseRedirect('/showall')
def back(request):
    return HttpResponseRedirect('/')    




