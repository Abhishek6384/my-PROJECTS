from django.apps import AppConfig


class WorkingConfig(AppConfig):
    name = 'working'
