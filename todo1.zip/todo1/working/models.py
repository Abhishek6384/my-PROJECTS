from django.db import models

class TodoItem(models.Model):
    content=models.TextField()
    time=models.TextField()
class Meta:
    db_table='todo'    


