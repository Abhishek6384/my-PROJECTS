from django.db import models

class Flower(models.Model):
    sepal_length=models.IntegerField()
    sepal_width=models.IntegerField()
    petal_length=models.IntegerField()
    petal_width=models.IntegerField()
    result=models.CharField(max_length=100)

    class Meta:
        db_table='flower'
