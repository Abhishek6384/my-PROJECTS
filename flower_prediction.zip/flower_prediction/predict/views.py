from django.shortcuts import render
from .models import Flower


import pickle
def predict(request):
    return render(request,'predict.html')


def values(request):
    if request.method=='POST':
        print('sdkfhd')
    sepal_length=request.POST.get('sepal_length')
    sepal_width=request.POST.get('sepal_width')
    petal_length = request.POST.get('petal_length')
    petal_width=request.POST.get('petal_width')
    

    with open('model/saved_model','rb') as f:
        mp=pickle.load(f)
    ans=mp.predict([[sepal_length,sepal_width,petal_length,petal_width]])
    result=None
    if ans[0]==0:
        result='Iris-setosa'
    elif ans[0]==1:
        result='Iris-versicolor'
    elif ans[0]==2:
        result="Iris-virginica"
    
    #saving the data in database
    
    new_item=Flower(sepal_length=sepal_length,sepal_width=sepal_width,petal_length=petal_length,petal_width=petal_width,result=result)
    new_item.save()
    
    return render(request,'output.html',{'sp_l':sepal_length,'sp_w':sepal_width,'pe_l':petal_length,'pe_w':petal_width,'result':result})




def result(request):
    all_data=Flower.objects.all()
    return render(request,'results.html',{'all_data':all_data}) 
    