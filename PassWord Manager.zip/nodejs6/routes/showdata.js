var express=require("express")
var router=express.Router()



var mongoose=require('mongoose')
var url='mongodb://localhost:27017/webdata'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({username:String,password:String,firstname:String,lastname:String,address:String,pincode:String,mobile:String})
var m1=mongoose.model('model2',schema,'user')

router.get('/show',function(req,res){
m1.find(function(err,result){
var str="<table border=1> <th> Sno.<th>Username<th>Password<th>Firstname<th>Lastname<th>Address<th>Pincode<th>Mobile No.<th>To remove"
for(i=0;i<result.length;i++)
{
str +="<tr><td>"+(parseInt(i)+parseInt(1))
str +="<td>" +result[i].username
str +="<td>" +result[i].password
str +="<td>" +result[i].firstname
str +="<td>" +result[i].lastname
str +="<td>" +result[i].address
str +="<td>" +result[i].pincode
str +="<td>" +result[i].mobile
str +="<td><a href=delete?username="+result[i].username + ">Remove </a>"
}
res.send(str)
})
})

module.exports=router