var express=require("express")
var router=express.Router()


var mongoose=require('mongoose')
var url='mongodb://localhost:27017/password'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({name:String,type:String,pass:String})
var m1=mongoose.model('model5',schema,'userdata')

router.get('/submit',function(req,res)
{var doc=new m1({name:req.query.n1,type:req.query.n2,pass:req.query.n3})
doc.save(function(err,result){
res.render("home2.html")
})

})

module.exports=router