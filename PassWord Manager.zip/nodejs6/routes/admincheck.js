var express=require("express")
var router=express.Router()


var mongoose=require('mongoose')
var url='mongodb://localhost:27017/webdata'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({username:String,password:String})
var m1=mongoose.model('model8',schema,'user')


router.get('/check',function(req,res){
m1.find({username:req.query.b1,password:req.query.b2},function(err,result)
{
if(result.length==0)
{
res.send("invalid user Try Again")

}
else
if(result[0].username=="abhishek" && result[0].password=="uhai")
{
    res.render('database.html')
}
})
})


module.exports=router