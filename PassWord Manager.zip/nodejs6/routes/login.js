var express=require("express")
var router=express.Router()


var mongoose=require('mongoose')
var url='mongodb://localhost:27017/webdata'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({username:String,password:String})
var m1=mongoose.model('model4',schema,'user')


router.get('/login',function(req,res){
m1.find({username:req.query.t1,password:req.query.t2},function(err,result)
{
if(result.length==0)
{
res.send("invalid user Try Again")

}
else
{
res.render("home2.html")
}
})
})


module.exports=router