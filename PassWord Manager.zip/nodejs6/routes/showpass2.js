var express=require("express")
var router=express.Router()


var mongoose=require('mongoose')
var url='mongodb://localhost:27017/password'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({name:String,type:String,pass:String})
var m1=mongoose.model('model7',schema,'userdata')


router.get('/showpass2',function(req,res){
m1.find({name:req.query.x1},function(err,result)
{
    if(result.length==0)
    {
    res.send("Specification not found")
    
    }
    else
    {	
    res.render("showdata2.html",{obj:result})
    }
})
})


module.exports=router