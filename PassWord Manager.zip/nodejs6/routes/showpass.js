var express=require("express")
var router=express.Router()



router.get('/show2',function(req,res){
    res.render("showpassPage.html")
    })
    


module.exports=router