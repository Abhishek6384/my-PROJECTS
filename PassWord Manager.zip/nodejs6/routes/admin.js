var express=require("express")
var router=express.Router()



router.get('/admin',function(req,res){
res.render("adminpage.html")
})


module.exports=router