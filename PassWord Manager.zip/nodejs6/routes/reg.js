var express=require("express")
var router=express.Router()


var mongoose=require('mongoose')
var url='mongodb://localhost:27017/webdata'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({username:String,password:String,firstname:String,lastname:String,address:String,pincode:String,mobile:String})
var m1=mongoose.model('model1',schema,'user')

router.get('/reg',function(req,res)
{var doc=new m1({username:req.query.t1,password:req.query.t2,firstname:req.query.t3,lastname:req.query.t4,address:req.query.t5,pincode:req.query.t6,mobile:req.query.t7})
doc.save(function(err,result){
res.render("loginpage.html")
})

})

module.exports=router