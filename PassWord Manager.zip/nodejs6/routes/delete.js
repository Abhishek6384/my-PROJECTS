var express=require("express")
var router=express.Router()



var mongoose=require('mongoose')
var url='mongodb://localhost:27017/webdata'
mongoose.connect(url)
var con=mongoose.connection
var schema=mongoose.Schema({username:String,password:String,firstname:String,lastname:String,address:String,pincode:String,mobile:String})
var m1=mongoose.model('model9',schema,'user')


router.get("/delete",function(req,res){
var r1=req.query.username
m1.deleteMany({username:r1},function(err,result){
res.send("Deleted Records : "+result.deletedCount)

})
})



module.exports=router