var express=require("express")

var router=express.Router()


router.get('/contactpage',function(req,res){
res.render('contactpage.html')
})


module.exports=router