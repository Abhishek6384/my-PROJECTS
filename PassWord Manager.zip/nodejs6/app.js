var express=require("express")
var app=express()
app.listen(3000,() =>console.log("server connected on port 3000"));
app.use(express.static(__dirname+"/public"))

var ejs=require('ejs')
app.engine('html',ejs.renderFile)
app.set('view engine','html')


var indexRouter=require('./routes/index')
var frontpageRouter=require('./routes/front')
var registerRouter=require('./routes/register')
var regRouter=require('./routes/reg')
var showRouter=require('./routes/showdata')
var contactRouter=require('./routes/contact')
var submitRouter=require('./routes/submit1')
var loginRouter=require('./routes/login')
var showpageRouter=require('./routes/showpass')
var showpassRouter=require('./routes/showpass2')
var adminRouter=require('./routes/admin')
var adminCheckRouter=require('./routes/admincheck')
var deleteRouter=require('./routes/delete')


app.get('/',indexRouter);
app.get('/frontpage',frontpageRouter);
app.get('/registration',registerRouter)
app.get('/reg',regRouter)
app.get('/show',showRouter)
app.get('/contactpage',contactRouter)
app.get('/login',loginRouter)
app.get('/submit',submitRouter)
app.get('/show2',showpageRouter)
app.get('/showpass2',showpassRouter)
app.get('/admin',adminRouter)
app.get('/check',adminCheckRouter)
app.get('/delete',deleteRouter)

